<?php

	define('STM_SLIDER_VERSION', '1.0');
	define('STM_SLIDER_PLUGIN_NAME', 'slider');
	define('STM_SLIDER_ROOT_PATH', STM_CONFIGURATIONS_PATH . '/slider');
	define('STM_SLIDER_URL', STM_CONFIGURATIONS_URL . 'slider');
	define('STM_SLIDER_PAGE_URL', get_admin_url() . '/admin.php?page=stm-slider-options');
	define('STM_SLIDER_POST_TYPE', 'stm_slider');
	define('STM_SLIDER_META_NAME', 'stm_slider_settings');
	define('STM_SLIDER_SLIDE_META_NAME', 'stm_slider_slide_settings');