<div class="pearl_add_pli">
	<div class="pearl_add_pli__button">
		<?php esc_html_e('Import page', 'stm-configurations'); ?>
	</div>
</div>