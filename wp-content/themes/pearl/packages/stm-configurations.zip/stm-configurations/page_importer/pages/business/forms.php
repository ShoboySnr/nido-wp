<?php $pearl_cf7 = array();
$pearl_cf7[2035] = '<div class="row">
<div class="col-md-6 col-sm-6">[text* your-name placeholder "Name*"]</div>
<div class="col-md-6 col-sm-6">[email* your-email placeholder "Email"]</div>
</div>
<div class="row stm_mgb_25">
<div class="col-md-6 col-sm-6">[select inquiry "Type of inquiry" "Consultation" "Meeting" "Credit"]</div>
<div class="col-md-6 col-sm-6">[textarea your-message placeholder "Your Message"]</div>
</div>
<div class="text-center">
[submit class:btn class:btn_lg class:btn_primary class:btn_solid class:btn_lg "Send Inquiry"]
</div>';
$pearl_cf7[1840] = '<div class="row form-reverse">
<div class="col-md-6 col-sm-6">[text* your-name placeholder "Name*"]</div>
<div class="col-md-6 col-sm-6">[email* your-email placeholder "Email*"]</div>
</div>
<div class="row form-reverse">
<div class="col-md-6 col-sm-6">[tel your-tel placeholder "Phone"]</div>
<div class="col-md-6 col-sm-6">[select country "Country" "USA" "France" "Germany"]</div>
</div>
<div class="form-reverse stm_mgb_60">[textarea your-message placeholder "Your Message"]</div>

[submit class:btn class:btn_primary class:btn_outline class:btn_lg class:wtc "Submit"]';