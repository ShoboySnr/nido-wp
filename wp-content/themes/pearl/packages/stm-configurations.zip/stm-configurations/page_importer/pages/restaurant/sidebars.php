<?php
$pearl_sidebars = array();