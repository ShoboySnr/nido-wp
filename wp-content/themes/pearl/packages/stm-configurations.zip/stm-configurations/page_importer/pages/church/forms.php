<?php $pearl_cf7 = array();$pearl_cf7[2698] = '<div class="row">
    <div class="col-md-12 form-group">
        [textarea textarea-978 class:form-control x6 placeholder  "Your Message"]
    </div>
</div>
<div class="row">
    <div class="col-md-6 form-group">
        [text text-854 class:form-control placeholder "Full name"]
    </div>
    <div class="col-md-6 form-group">
        [email email-412 class:form-control placeholder "Email Address"]
    </div>
</div>
<div class="row">
    <div class="col-md-6 form-group">
        [tel tel-544 class:form-control placeholder "Phone number"]
    </div>
    <div class="col-md-6 form-group">
       [submit class:btn_solid class:btn_secondary "Submit"]
    </div>
</div>';