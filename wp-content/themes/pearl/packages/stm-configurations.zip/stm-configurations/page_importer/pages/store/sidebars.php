<?php
$pearl_sidebars = array();
$pearl_sidebars[274] = '[vc_row][vc_column][vc_widget_sidebar sidebar_id="default"][/vc_column][/vc_row]';