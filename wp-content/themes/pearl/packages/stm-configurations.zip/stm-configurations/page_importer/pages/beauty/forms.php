<?php $pearl_cf7 = array();$pearl_cf7[1378] = '<div class="row">
<div class="col-md-12 col-sm-12">
[text* your-name placeholder "Your Name"]
</div>
<div class="col-md-12 col-sm-12">
[tel* tel-354 placeholder "You phone"]
</div>
</div>

[submit "Submit"]';$pearl_cf7[1298] = '<div class="row"><div class="col-md-6 col-sm-6">[text* your-name placeholder "Your Name"]</div><div class="col-md-6 col-sm-6">[email* your-email placeholder "Your Email"]</div></div>[textarea your-message placeholder "Your Message"]

[submit "Submit"]';$pearl_cf7[1215] = '<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            [text text-13 placeholder "Your name"]
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
            [tel* tel-577 placeholder "You phone number"]
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
            [email email-255 placeholder "Your e-mail"]
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        [textarea textarea-421 placeholder "Message"]
       </div>
    </div>
   <div class="clearfix"></div>
        <div class="col-md-12">
              <div class="form-group">
                   [submit "Submit"]
             </div>
        </div>
</div>';