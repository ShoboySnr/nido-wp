<?php $pearl_cf7 = array();$pearl_cf7[4221] = '<div class="row">
	<div class="col-xs-1 hidden-xxs">
		<i class="stmicon-bon-pen mtc"></i>
	</div>
	<div class="col-xs-11 col-xxs-12">
		<div class="form-group">
			[text* text-726 placeholder "Your name, sir?"]
		</div>
	</div>
	<div class="col-xs-1 hidden-xxs">
		<i style="font-size: 16px;"  class="stmicon-bon-envelope mtc"></i>
	</div>
	<div class="col-xs-11 col-xxs-12">
		<div class="form-group">
			[email email-794 placeholder "E-mail"]
		</div>
	</div>
	<div class="col-xs-1 hidden-xxs">
		<i style="font-size: 19px;"  class="stmicon-text mtc"></i>
	</div>
	<div class="col-xs-11 col-xxs-12">
		<div class="form-group">
			[text* text-724 placeholder "Subject"]
		</div>
	</div>
	<div class="col-xs-11 col-xxs-12 col-xs-offset-1">
		[textarea* textarea-77 placeholder "Comment..."]
	</div>
	<div class="col-xs-11 col-xxs-12  col-xs-offset-1">
		[submit class:btn class:btn_solid class:btn_primary "Send"]
	</div>
</div>';$pearl_cf7[4123] = '<div class="row">
	<div class="col-md-4">
		<div class="form-group text-center">
			 <label>Date *</label>   <i class="stmicon-bon-calendar mtc"></i>  [text* date placeholder class:stm_datepicker class:text-center "Which date?"]
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group text-center">
			 <label>Time *</label>			 <i class="stmicon-bon-clock mtc"></i>			 [text* time placeholder class:stm_timepicker class:text-center "What time?"]
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group text-center">
			 <label>Guests *</label>			 <i class="stmicon-bon-user mtc"></i>			 [number number-43 min:1 max:40 placeholder class:text-center "How many of you?"]
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-4">
		<div class="form-group text-center">
			 <label>Name</label>           <i class="stmicon-bon-pen mtc"></i>			 [text text-738 placeholder  class:text-center "You name, sir?"]
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group text-center">
			 <label>E-mail</label> <i class="stmicon-bon-envelope mtc"></i>			 [email email-624 placeholder class:text-center "Not necessarily"]
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group text-center">
			 <label>Phone</label> <i class="stmicon-bon-phone mtc"></i> 			 [tel tel-479 placeholder class:text-center "Please enter your number"]
		</div>
	</div>
</div>
<div class="row">
	<div class="form-group text-center">
		 [submit class:btn class:btn_solid class:btn_primary "Reservation"]
	</div>
</div>';