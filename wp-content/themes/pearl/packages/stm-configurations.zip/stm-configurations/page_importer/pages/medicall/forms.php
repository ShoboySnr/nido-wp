<?php $pearl_cf7 = array();$pearl_cf7[1533] = '<div class="row">
      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group form_icon user mtc_b">
               [text* name placeholder "Name*"]
            </div>
            <div class="form-group form_icon dial_pad mtc_b">
               [tel* phone placeholder "Phone*"]
            </div>
            <div class="form-group form_icon date mtc_b">
               [text* date placeholder class:stm_datepicker "Date*"]
            </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group form_icon user mtc_b">
               [text last_name placeholder "Last Name"]
            </div>
            <div class="form-group form_icon mail mtc_b">
               [email email placeholder "E-mail (Optional)"]
            </div>
            <div class="form-group form_icon time mtc_b">
               [text* time placeholder class:stm_timepicker "Time*"]
            </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group form_icon message textarea_230 mtc_b">
                [textarea message placeholder "Your Message"]
           </div>
      </div>
</div>
[submit "Make an Appointment"]';$pearl_cf7[1373] = '<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            [text text-13 placeholder "Your name"]
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
            [tel* tel-577 placeholder "You phone number"]
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
            [email email-255 placeholder "Your e-mail"]
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        [textarea textarea-421 placeholder "Message"]
       </div>
    </div>
   <div class="clearfix"></div>
        <div class="col-md-12">
              <div class="form-group">
                   [submit "Submit"]
             </div>
        </div>
</div>';$pearl_cf7[108] = '<div class="row form-reverse">
      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group form_icon user mtc_b">
               [text* name placeholder "Name*"]
            </div>
            <div class="form-group form_icon dial_pad mtc_b">
               [tel* phone placeholder "Phone*"]
            </div>
            <div class="form-group form_icon date mtc_b">
               [text* date placeholder class:stm_datepicker "Date*"]
            </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group form_icon user mtc_b">
               [text last_name placeholder "Last Name"]
            </div>
            <div class="form-group form_icon mail mtc_b">
               [email email placeholder "E-mail (Optional)"]
            </div>
            <div class="form-group form_icon time mtc_b">
               [text* time placeholder class:stm_timepicker "Time*"]
            </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group form_icon message textarea_230 mtc_b">
                [textarea message placeholder "Your Message"]
           </div>
      </div>
</div>
[submit "Make an Appointment"]';