<?php

require_once(STM_CONFIGURATIONS_PATH . '/widgets/text.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/follow.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/contacts.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/gallery.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/pages.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/post_list.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/class-stm-widget-categories.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/class-stm-widget-search.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/class-stm-widget-recent-posts.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/class-stm-widget-popular-posts.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/class-stm-widget-working-hours.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/class-stm-widget-tag-cloud.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/class-stm-widget-recent-comments.php');
require_once(STM_CONFIGURATIONS_PATH . '/widgets/class-stm-widget-custom-menu.php');